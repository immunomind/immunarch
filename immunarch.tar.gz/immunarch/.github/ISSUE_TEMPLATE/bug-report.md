---
name: "\U0001F41B Bug Report"
about: Submit a bug report to help us improve Immunarch

---

## 🐛 Bug
<!-- Place here a clear description of what the bug is. -->

## To Reproduce
Steps to reproduce the behavior:

1.
2.
3.

<!-- If you have a data sample, code sample, screenshots, error messages, stack traces, please provide it here as well -->

## Expected behavior
<!-- Place here a clear description of what you expected to happen. -->

## Additional context
<!-- Add here any other context about the problem. -->

