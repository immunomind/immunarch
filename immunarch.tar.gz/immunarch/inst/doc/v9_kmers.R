## ----setup, include=FALSE, echo=FALSE------------------------------------
# knitr::knit_hooks$set(optipng = knitr::hook_optipng)
# knitr::opts_chunk$set(optipng = '-o7')

knitr::opts_chunk$set(echo = TRUE)
knitr::opts_chunk$set(fig.align = "center")
knitr::opts_chunk$set(fig.width = 12)
knitr::opts_chunk$set(fig.height = 5)

library(immunarch)
data(immdata)

## ------------------------------------------------------------------------
kmers = getKmers(immdata$data[[1]], 3)
kmers

## ------------------------------------------------------------------------
kmers = getKmers(immdata$data, 5)
kmers

## ------------------------------------------------------------------------
kmers = getKmers(immdata$data[[1]], 3, .coding=F)
kmers

## ------------------------------------------------------------------------
kmers = getKmers(immdata$data, 5)
vis(kmers)

## ------------------------------------------------------------------------
p1 = vis(kmers, .head = 5)
p2 = vis(kmers, .head = 10)
p3 = vis(kmers, .head = 30)
grid.arrange(p1, p2, ncol=2)
p3

## ------------------------------------------------------------------------
p1 = vis(kmers, .head = 10, .position = "stack")
p2 = vis(kmers, .head = 10, .position = "fill")
p3 = vis(kmers, .head = 10, .position = "dodge")
grid.arrange(p1, p2, ncol=2)
p3

## ------------------------------------------------------------------------
p1 = vis(kmers, .head = 10, .position = "stack")
p2 = vis(kmers, .head = 10, .position = "stack", .log = T)

grid.arrange(p1, p2, ncol=2)

## ------------------------------------------------------------------------
kmers = getKmers(immdata$data[[1]], 5)
kmer_profile(kmers)

## ------------------------------------------------------------------------
kmer_profile(kmers, "freq")
kmer_profile(kmers, "prob")
kmer_profile(kmers, "wei")
kmer_profile(kmers, "self")

## ------------------------------------------------------------------------
kp = kmer_profile(kmers, "self")
p1 = vis(kp)
p2 = vis(kp, .plot = "seq")
grid.arrange(p1, p2, ncol=2)

