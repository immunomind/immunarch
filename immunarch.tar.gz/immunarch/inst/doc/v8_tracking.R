## ----setup, include=FALSE, echo=FALSE------------------------------------
# knitr::knit_hooks$set(optipng = knitr::hook_optipng)
# knitr::opts_chunk$set(optipng = '-o7')

knitr::opts_chunk$set(echo = TRUE)
knitr::opts_chunk$set(fig.align = "center")
knitr::opts_chunk$set(fig.width = 12)
knitr::opts_chunk$set(fig.height = 5)

library(immunarch)
data(immdata)

## ----warning=F-----------------------------------------------------------
tc1 = trackClonotypes(immdata$data, list(1, 5), .col = "nt")

## ----warning=F-----------------------------------------------------------
tc2 = trackClonotypes(immdata$data, list("MS1", 10), .col = "aa+v")

## ----fig.height=7, warning=FALSE-----------------------------------------
p1 = vis(tc1)
p2 = vis(tc2)

grid.arrange(p1, p2)

## ----warning=F-----------------------------------------------------------
target = c("CASSLEETQYF", "CASSDSSGGANEQFF", "CASSDSSGSTDTQYF", "CASSLAGGYNEQFF", "CASSDSAGGTDTQYF", "CASSLDSYEQYF", "CASSSAGGYNEQFF")
tc = trackClonotypes(immdata$data, target, .col = "aa")
vis(tc)

## ------------------------------------------------------------------------
target = immdata$data[[1]] %>% select(CDR3.aa, V.name) %>% head(10)

target

## ----warning=F-----------------------------------------------------------
tc = trackClonotypes(immdata$data, target)
vis(tc)

## ----warning=F, fig.height=8---------------------------------------------
target = c("CASSLEETQYF", "CASSDSSGGANEQFF", "CASSDSSGSTDTQYF", "CASSLAGGYNEQFF", "CASSDSAGGTDTQYF", "CASSLDSYEQYF", "CASSSAGGYNEQFF")
tc = trackClonotypes(immdata$data, target, .col = "aa")
p1 = vis(tc, .plot = "smooth")
p2 = vis(tc, .plot = "area")
p3 = vis(tc, .plot = "line")

grid.arrange(p1, p2, p3)

