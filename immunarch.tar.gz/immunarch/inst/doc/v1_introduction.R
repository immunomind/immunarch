## ----setup, include=FALSE, echo=FALSE------------------------------------
# knitr::knit_hooks$set(optipng = knitr::hook_optipng)
# knitr::opts_chunk$set(optipng = '-o7')

knitr::opts_chunk$set(echo = TRUE)
knitr::opts_chunk$set(fig.align = "center")
knitr::opts_chunk$set(fig.width = 12)
knitr::opts_chunk$set(fig.height = 6)

library(immunarch)
# source("../R/testing.R")
# immdata = load_test_data()
data(immdata)

## ----eval=FALSE----------------------------------------------------------
#  # Load the package
#  library(immunarch)
#  
#  # Load the data to the package
#  immdata = repLoad("path/to/your/folder/with/repertoires")
#  # If you folder contains metadata.txt file, immdata will have two elements:
#  # - immdata$data with a list of parsed repertoires
#  # - immdata$meta with the metadata file
#  
#  # If you don't have your data, you can load repertoire data
#  # that comes with immunarch. Uncomment (i.e., remove the "#" symbol)
#  # in the next line to load the data
#  # data(immdata)
#  
#  # Compute and visualise overlap statistics
#  ov = repOverlap(immdata$data)
#  vis(ov)
#  
#  # Cluster samples using K-means algorithm applied to the number of overlapped clonotypes
#  # and visualise the results
#  ov.kmeans = repOverlapAnalysis(ov, .method = "mds")
#  vis(ov.kmeans)
#  
#  # Compute and visualise gene usage with samples, grouped by their disease status
#  gu = geneUsage(immdata$data)
#  vis(gu, .by="Status", .meta=immdata$meta)
#  
#  # Compute Jensen-Shannon divergence among gene distributions of samples,
#  # cluster samples using the hierarchical clustering and visualise the results
#  gu.clust = geneUsageAnalysis(gu, .method = "js+hclust")
#  vis(gu.clust)
#  
#  # Compare diversity of repertoires and visualise samples, grouped by two parameters
#  div = repDiversity(immdata$data, .method = "chao1")
#  vis(div, .by=c("Status", "Lane"), .meta=immdata$meta)
#  
#  # Manipulate the visualisation of diversity estimates to make the plot publication-ready
#  div.plot = vis(div, .by=c("Status", "Lane"), .meta=immdata$meta)
#  fixVis(div.plot)

## ----eval=FALSE----------------------------------------------------------
#  data(immdata)

