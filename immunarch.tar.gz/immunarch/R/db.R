# makeDB
# loadDB
# showDB
# infoDB show tables in DB

# db_info <- function (.data) {
#   sapply(1:length(.data), function (i) {
#     c(names(.data)[i], nrow(collect(.data[[i]], count)))
#   })
# }


#
# to_df - to data frame
# to_dt - to data table
# db_col - get column
# db_add - add new column
# db_rem - remove column
# db_write - write / overwrite new table
