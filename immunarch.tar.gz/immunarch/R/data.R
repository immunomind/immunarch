#' Immune repertoire dataset
#'
#' A testing dataset containing clonotypes.
#'
#' @format A list of two elements. First element "data" is a list with data frames with clonotype tables.
#' Second element "meta" is a metadata file.
#' \describe{
#'   \item{price}{price, in US dollars}
#'   \item{carat}{weight of the diamond, in carats}
#'   ...
#' }
#' @source \url{http://www.work-in-progress.info/}
"immdata"
