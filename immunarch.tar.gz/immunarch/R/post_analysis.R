# overlap => distance matrix
# gene usage => N-dimensional vector of values
# diversity => vector of values

# (both) vector of values => distance matrix
# N-dimensional vector of values => clustering
# N-dimensional vector of values => dimensionality reduction
# N-dimensional vector of values => statistical test
# N-dimensional vector of values => grouped statistical test
# vector of values => grouped statistical test

# distance matrix => clustering
# distance matrix => dimensionality reduction
# distance matrix => vis

# dimensionality reduction => clustering
# dimensionality reduction => vis

# clustering => vis

# statistical test => vis
# grouped statistical test => vis

# distance matrix
# - cor
# - js
# - cor
# - cosine

# clustering
# - hclust
# - dbscan
# - kmeans

# dimensionality reduction
# - tsne
# - pca
# - mds

# stat test / grouped stat test
# - kruskall
# - wilcox

# postAnalysis <- function (.data)

# immunr_clustering_preprocessing <- function (...) {
  # check for the right input class
  # preprocess data somehow
# }
