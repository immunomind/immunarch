#' Statistical analysis of groups
#'
immunr_permut <- function () {
  stop(IMMUNR_ERROR_NOT_IMPL)
}

# groups
immunr_mann_whitney <- function () {
  stop(IMMUNR_ERROR_NOT_IMPL)
}

immunr_kruskall <- function (.dunn = T) {
  stop(IMMUNR_ERROR_NOT_IMPL)
}

immunr_logreg <- function () {
  stop(IMMUNR_ERROR_NOT_IMPL)
}
